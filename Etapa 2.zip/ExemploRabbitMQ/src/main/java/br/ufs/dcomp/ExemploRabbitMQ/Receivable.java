package br.ufs.dcomp.ExemploRabbitMQ;

import java.io.IOException;

import com.rabbitmq.client.Channel;
import com.rabbitmq.client.DeliverCallback;

public class Receivable implements Runnable{
    private String queueName;
    private DeliverCallback deliverCallback;
    private Channel channel;

    public Receivable(Channel channel, String queueName, DeliverCallback deliverCallback) {
        this.channel = channel;
        this.queueName = queueName;
        this.deliverCallback = deliverCallback;
    }

    @Override
    public void run() {
        try {
            channel.basicConsume(queueName, true, deliverCallback, consumerTag ->{});
        } catch (IOException e) {
            // TODO Auto-generated catch block
            e.printStackTrace();
        }
    }
    
}
