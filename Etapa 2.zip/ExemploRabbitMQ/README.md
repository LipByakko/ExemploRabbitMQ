# ExemploRabbitMQ

Como gerar jar usando maven:
    
mvn clean compile assembly:single
